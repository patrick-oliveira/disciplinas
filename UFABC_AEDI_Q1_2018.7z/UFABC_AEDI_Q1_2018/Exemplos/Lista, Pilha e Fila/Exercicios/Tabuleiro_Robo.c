#include <stdio.h>
#define M 5
#define N 7

typedef struct coordenada {
  int l;
  int c;
} coord;

coord lista[M*N];
int tabuleiro[M][N];

int main(){
  int achei = 0;
  coord l_aux;
  int i = 0, j = 0;
  // a saida esta em xy.
  while(!achei){
      if((j+1 < x) && (tabuleiro[i][j+1] == 1)){
        colocanafila(i, j+1);
      } else 
  }


  return 0;
}
