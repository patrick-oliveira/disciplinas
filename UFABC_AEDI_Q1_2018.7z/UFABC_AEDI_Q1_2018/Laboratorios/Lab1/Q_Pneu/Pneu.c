#include <stdio.h>

int main(void){
    int N, M;
    
    scanf("%d", &N);
    scanf("%d", &M);
    
    printf("%d\n", N - M);
    
    return 0;
}